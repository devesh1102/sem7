load('Q4_values.mat')
plot (x,log(N))
find(x== 1e17)